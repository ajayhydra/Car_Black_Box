/*
 * File:   disp_menu.c
 * Author: ajay  reddy
 *
 * Created on June 4, 2024, 6:28 PM
 */


#include <xc.h>
#include "clcd.h"
#include "main.h"
#include "matrix_keypad.h"


static char menu_opt[5][17] = {"view log        ", "Download log    ", "Clear log       ", "Change Password ", "Set time        "};
static char option = 0;
static char star_flag = 0;
static unsigned int sw5_wait = 0;
static unsigned int sw6_wait = 0;
static char res_opt;
unsigned int status;
char menu_f;

void disp_menu(void) {
    
    // Read the key from the keypad
    char menu_key = read_switches(LEVEL_CHANGE);    // For long press detection change the key press into level change

    // scrolling down (press switch 6)
    if (menu_key == MK_SW6) 
    {
        sw6_wait++;
        if (sw6_wait > 1000)
        { 
            sw6_wait = 0;
            CLEAR_DISP_SCREEN;
            status = DASHBOARD; // Go back to Dashboard
            return;
        }
    }
    else if (sw6_wait > 0 && sw6_wait <= 1000) {
        sw6_wait = 0;
        if (star_flag == 0) 
        {
            CLEAR_DISP_SCREEN;
            star_flag = 1;
        } else if (option < 3) {
            option++;
        }
    } else
        sw6_wait = 0;   //Reset

    //scrolling up (press switch 5)
    if (menu_key == MK_SW5) {
        sw5_wait++;
        if (sw5_wait > 1000) { // Approx 2 seconds long press
            sw5_wait = 0;
            status = MENU_ENTER;
            CLEAR_DISP_SCREEN;
            res_opt = star_flag ? option + 1 : option;
            
            // Enter into particular menu
            switch (res_opt) {
                case 0:
                    menu_f = VIEWLOG;
                    break;
                case 1:
                   menu_f = DOWNLOAD_LOG;
                    break;
                case 2:
                    menu_f = CLEAR_LOG;
                    break;
                case 3:
                    menu_f = CHANGE_PASS;
                    break;
                case 4:
                    menu_f = SET_TIME;
                    break;
            }
            return;
        }
    } else if (sw5_wait > 0 && sw5_wait <= 1000) 
    {
        sw5_wait = 0;
        if (star_flag == 1) 
        {
            CLEAR_DISP_SCREEN;
            star_flag = 0;
        } 
        else if (option > 0) 
        {
            option--;
        }
    } else sw5_wait = 0;    //Reset


    // Display the menu options on CLCD
    clcd_putch(star_flag ? ' ' : '*', LINE1(0));    //Based on star flag print the star
    clcd_putch(star_flag ? '*' : ' ', LINE2(0));

    // Print the current and next menu options on the CLCD
    clcd_print(menu_opt[option],LINE1(1));
    clcd_print(menu_opt[option + 1],LINE2(1));
}