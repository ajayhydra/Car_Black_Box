/*
 * File:   clear.c
 * Author: ajay  reddy
 *
 * Created on June 11, 2024, 6:17 PM
 */

#include <xc.h>
#include "main.h"
#include "clcd.h"

int logcount;
char lap;
char time[9];
unsigned int status;
unsigned short adc_reg_val;

void clear_the_log()
{
    static int flag=1;
    static int cdelay=0;
    //clear log
    if(flag)
    {
        lap=0;
        logcount=1;
        get_time(); //get the time
        store_the_event(8,adc_reg_val); //store clear log event
    }
    flag=0;
    clcd_print("CLEAR LOG",LINE1(0));
    clcd_print("SUCCESSFUL",LINE2(0));
    if(cdelay++==2000)
    {
       cdelay=0;
       flag=1;
       CLEAR_DISP_SCREEN;
       status=MENU;     //change the state to menu
    }
    
}
