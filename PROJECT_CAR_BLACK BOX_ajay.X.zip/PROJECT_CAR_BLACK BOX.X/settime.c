/*
 * File:   settime.c
 * Author: ajay  reddy
 *
 * Created on June 12, 2024, 11:37 AM
 */

#include <xc.h>
#include "main.h"
#include "clcd.h"
#include "matrix_keypad.h"
#include "ds1307t.h"

//unsigned char key;
unsigned int once=1;
char time[9];
unsigned int status;
unsigned short adc_reg_val;
int loopcount;
unsigned char key1;

void set_the_time(void) 
{
    static int blink=0,flag=1;
    static unsigned int wait=0,delay=0,data;
    static char time1[9];
    char set_key = read_switches(LEVEL_CHANGE); 
    if(flag)
    {
        get_time();
        flag=0;
    }
    clcd_print("SET TIME",LINE1(0));
    if(blink==0)    //blink the second field
    {
        if(delay++<=1000)
        {
            for(int i=0;i<6;i++)
            {
                clcd_putch(time[i],LINE2(i));
            }
            clcd_print("  ",LINE2(6));
        }
        else if(delay<=2000)
        {
            
            for(int i=0;i<8;i++)
            {
                clcd_putch(time[i],LINE2(i));
            }
            if(delay==2000)
            delay=0;
        }
    }
    else if(blink==1)   //blink the minute part
    {
        if(delay++<=1000)
        {
            for(int i=0;i<3;i++)
            {
                clcd_putch(time[i],LINE2(i));
            }
            clcd_print("  ",LINE2(3));
            for(int i=5;i<8;i++)
            {
                clcd_putch(time[i],LINE2(i));
            }
        }
        else if(delay<=2000)
        {
            if(delay==2000)
            delay=0;
            for(int i=0;i<8;i++)
            {
                clcd_putch(time[i],LINE2(i));
            }
             if(delay==2000)
            delay=0;
        }
        
    }
    else if(blink==2)  //blink the hour part 
    {
        if(delay++<=1000)
        {
            clcd_print("  ",LINE2(0));
            for(int i=2;i<8;i++)
            {
                clcd_putch(time[i],LINE2(i));
            }
        }
        else if(delay<=2000)
        {
            
            for(int i=0;i<8;i++)
            {
                clcd_putch(time[i],LINE2(i));
            }
            if(delay==2000)
            delay=0;
        }
        
    }
    if(set_key == 0xFF)
    {
        once = 1;
    }
    if(set_key!=0xFF && once)
    {
        //clcd_putch(key,LINE1(0));
        if(set_key==MK_SW5 && once)    
        {
            key1=set_key;
            if(++wait==2000)
            {
                once=0;
            }
        }
        else if(set_key == MK_SW6 && once) 
        {
            key1=set_key;
            if(++wait==2000)
            {
                once=0;
            }
        }
    }
    else
    {
        if(key1==MK_SW5 && wait<2000)   //increment the time
        {
            wait=0;
            key1=0xFF;
            if(blink==0)
            {
                data=((time[6] - 48) * 10) +((time[7] - 48));
                if(data<59)
                {
                    data++;
                }
                else 
                {
                    data=0;
                }
                time[6]=data/10 + '0';
                time[7]=data%10 + '0';
            }
            else if(blink==1)
            {
                data=((time[3] - 48) * 10) +((time[4] - 48));
                if(data<59)
                {
                    data++;
                }
                else
                {
                    data=0;
                }
                time[3]=data/10 + '0';
                time[4]=data%10 + '0';
                
            }
            else
            {
                data=((time[0] - 48) * 10) +((time[1] - 48));
                if(data<23)
                {
                    data++;
                }
                else
                {
                    data=0;
                }
                time[0]=data/10 + '0';
                time[1]=data%10 + '0';   
            }
        }
        else if(key1 == MK_SW6 && wait<2000)  //change the field
        {
            key1=0xFF;
            wait=0;
            if(blink==2)
                blink=0;
            else
                blink++;
        }
        else if(key1==MK_SW5 && wait==2000)  //save the time
        {
            key1=0xFF;
            wait=0;
            if (loopcount<10)
            {
                loopcount++;
            }
            for(int i=0;i<9;i++)
            {
                time1[i]=time[i];
            }
            store_the_event(9,adc_reg_val);
            data=(time1[6] - 48)<<4;
            data=data | (time1[7]-48);
            write_ds1307(SEC_ADDR,data);
            data=(time1[3] - 48)<<4;
            data=data | (time1[4]-48);
             write_ds1307(MIN_ADDR,data);
            data=(time1[0] - 48)<<4;
            data=data | (time1[1]-48);
             write_ds1307(HOUR_ADDR,data);
             for(int i = 3000;i--;)
             {
                 clcd_print(time1,LINE1(0));
                 clcd_print("  SUCCESSFUL    ",LINE2(0));
             }
             status=MENU;
             CLEAR_DISP_SCREEN;
             
             blink=0;
             wait=0;
        }
        else if(key1==MK_SW6 && wait==2000)   //don't save the time
        {
            key1=0xFF;
            wait=0;
            blink=0;
            CLEAR_DISP_SCREEN;
            status=MENU;
            
        }
        
    }  
}
