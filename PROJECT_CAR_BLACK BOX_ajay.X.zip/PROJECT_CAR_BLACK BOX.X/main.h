#ifndef MAIN_H
#define MAIN_H


 //main
#define DASHBOARD 8
#define PASSWORD 7
#define MENU 6
#define VIEWLOG 1
#define DOWNLOAD_LOG 2
#define CLEAR_LOG 3
#define SET_TIME 4
#define CHANGE_PASS 5
#define MENU_ENTER 9
#define SLAVE_READ		0xA1
#define SLAVE_WRITE		0xA0

#define RX_PIN					TRISC7
#define TX_PIN					TRISC6


//adc
#define CHANNEL4		0x04
void init_adc(void);
unsigned short read_adc(unsigned char channel);

//eeprom
void write_internal_eeprom(unsigned char address, unsigned char data); 
unsigned char read_internal_eeprom(unsigned char address);

//timer
void init_timer0(void);


//functions
void dashboard(unsigned int ev_i,unsigned short speed);
void collision(void);
void store_the_event(unsigned ind,unsigned short speed);
void get_time(void);
 
 //password
 int pass_cmp();
void password();


//i2c
void init_i2c(void);
void i2c_start(void);
void i2c_rep_start(void);
void i2c_stop(void);
void i2c_write(unsigned char data);
unsigned char i2c_read(void);

//EEPROM
void write_ext_eeprom(unsigned char address1,  unsigned char data);
unsigned char read_ext_eeprom(unsigned char address1);

//UART
void init_uart(void);
void putch(unsigned char byte);
int puts(const char *s);
unsigned char getch(void);
unsigned char getch_with_timeout(unsigned short max_time);
unsigned char getche(void);




//menu
void disp_menu(void);
void change_password();
void view_log();
void download_log();
void clear_the_log();
void set_the_time(void);
int new_pass_cmp();
void get_time(void);
void update_display(int blink, int delay);
void increment_time_segment(int *data, int max_value, int index1, int index2);




#endif