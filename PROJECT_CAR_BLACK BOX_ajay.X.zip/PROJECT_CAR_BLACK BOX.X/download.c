/*
 * File:   download.c
 * Author: ajay  reddy
 *
 * Created on June 12, 2024, 11:25 AM
 */


#include <xc.h>
#include "main.h"
#include "clcd.h"

#define MAX_LOG_COUNT 10
#define LOG_DELAY 2000

int logcount;
char ev[11][3];
unsigned int status;
unsigned short adc_reg_val;

void download_log()
{
    char data;
    char arr[5];
    static int flag = 1;
    static int ddelay = 0;

    if (flag)
    {
        if (logcount < MAX_LOG_COUNT)
        {
            logcount++;
        }
        store_the_event(7, adc_reg_val);

        puts("#  TIME     EV  SP\n\r");
        for (int i = 0; i < logcount-1 ; i++)
        {
            for (int j = 0; j < 5; j++)
            {
                data = read_ext_eeprom((i * 5) + j);
                arr[j] = data;
            }
            putch(i + '0');
            puts("  ");
            putch((arr[0] / 10) + '0');
            putch((arr[0] % 10) + '0');
            putch(':');
            putch((arr[1] / 10) + '0');
            putch((arr[1] % 10) + '0');
            putch(':');
            putch((arr[2] / 10) + '0');
            putch((arr[2] % 10) + '0');
            puts(" ");
            puts(ev[arr[3]]);
            puts("  ");
            putch((arr[4] / 10) + '0');
            putch((arr[4] % 10) + '0');
            puts("\n\r");
        }
        flag = 0; // Set flag to 0 after processing
    }

    clcd_print("DOWNLOAD LOG", LINE1(0));
    clcd_print("SUCCESSFUL", LINE2(0));

    if (ddelay++ == LOG_DELAY)
    {
        ddelay = 0;
        CLEAR_DISP_SCREEN;
        status = MENU;
        flag = 1; // Reset flag after delay and state transition
    }
}

