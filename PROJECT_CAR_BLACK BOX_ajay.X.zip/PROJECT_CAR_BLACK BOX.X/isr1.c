/*
 * File:   isr1.c
 * Author: ajay  reddy
 *
 * Created on June 7, 2024, 5:35 PM
 */

#include <xc.h>
#include "main.h"

unsigned int sec;
void __interrupt() isr(void)
{
    static int count=0;
	if (TMR0IF)
	{
		TMR0 = TMR0 + 8;

		if (count++ == 20000)
		{
			count = 0;
			sec--;
		}
        TMR0IF = 0;
	}
}