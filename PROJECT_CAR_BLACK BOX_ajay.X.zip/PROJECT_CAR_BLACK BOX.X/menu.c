#include <xc.h>
#include "clcd.h"
#include "main.h"
#include "matrix_keypad.h"

char menu[5][15] = {"VIEW LOG", "DOWNLOAD LOG", "CLEAR VIEW LOG", "SET TIME", "CHANGE PASSWORD"};
unsigned int mindex = 0;
unsigned int flag = 0;
unsigned char key;

void disp_menu(void)
{
    if (key == MK_SW5 && flag == 0)
    {
        CLEAR_DISP_SCREEN;
        clcd_putch('*', LINE2(flag));
        clcd_print(menu[mindex], LINE1(1));
        clcd_print(menu[mindex + 1], LINE2(1));
    }
    else if (key == MK_SW6 && flag == 1)
    {
        CLEAR_DISP_SCREEN;
        clcd_putch('*', LINE2(flag));
        clcd_print(menu[mindex - 1], LINE1(1));
        clcd_print(menu[mindex], LINE2(1));
    }

    if (key == MK_SW5)
    {
        if (mindex < 4) 
        {
            mindex++;
            flag = 1;
        }
    }
    else if (key == MK_SW6)
    {
        if (mindex > 0) 
        {
            mindex--;
            flag = 0;
        }
    }
}
