/*
 * File:   change_password.c
 * Author: ajay  reddy
 *
 * Created on June 11, 2024, 11:18 AM
 */


#include <xc.h>
#include"clcd.h"
#include"main.h"
#include"matrix_keypad.h"

unsigned char key;
unsigned int once=1;
char arr[4];
char pass[4];
unsigned short adc_reg_val;
unsigned int status;


//compreing the two entered passwords are matched ore not
int new_pass_cmp()
{
    int i;
    for(i=0;i<4;i++)
    {
        
        if(pass[i]!=arr[i])
        {
            return 0;
        }
    }
    return 1;
}

void change_password() {
    static int count = 0, step = 0, res = 0;
    static unsigned long delay = 0, delay1 = 0;

    //char c_key = read_switches(LEVEL_CHANGE); 
    
    if (step == 0) {
        clcd_print("Enter NEW PASSWORD", LINE1(0)); //first step for enter password
    } else if (step == 1) {
        clcd_print("RE-ENTER PASSWORD", LINE1(0)); //second step for renter password
    }
    

    if (step < 2)
    {
        if (count < 4) 
        {
            
            if (delay++ <= 1000) {
                clcd_putch('_', LINE2(count));   // displaying blinking cursor on clcd
            } else if (delay <= 2000) {
                clcd_putch(' ', LINE2(count));
                if (delay == 2000) delay = 0;
            }

            
            if (key == MK_SW5 || key == MK_SW6 )  // key press for storing 1's and o's in to arrays
            {
                clcd_putch('*', LINE2(count));
                char input_char = (key == MK_SW5) ? '0' : '1';
                
                if (step == 0) 
                {
                    arr[count] = input_char;
                } 
                else {
                    pass[count] = input_char;
                }
                
                count++;
               // once = 0;
            }
            
        }
        else 
        {
           
            if (step == 0)  //updating step 1
            {
                step = 1;
            }
            else if (step == 1) //uopdating step 2
            {
                step = 2;
            }
            count = 0;
            CLEAR_DISP_SCREEN;
        }
    } else if (step == 2) {
        
        res = new_pass_cmp(); //comparing two passwords
        if (res) {
            for (int i = 0; i < 4; i++) {
                write_ext_eeprom(200 + i, pass[i]); //writting passwords in to eeprom
            }
            store_the_event(10,adc_reg_val);
            clcd_print("CHANGE PASSWORD", LINE1(0));
            clcd_print("SUCCESSFUL", LINE2(0));
        } else {
            clcd_print("CHANGE PASSWORD", LINE1(0));
            clcd_print("FAILURE", LINE2(0));
        }
        step = 3;
    } 
    else if (step == 3) {
        
        if (delay1++ == 50000) {
            status = MENU; //upadate status to menu
            delay1 = 0;
            step = 0;
            CLEAR_DISP_SCREEN;
        }
    }
}
