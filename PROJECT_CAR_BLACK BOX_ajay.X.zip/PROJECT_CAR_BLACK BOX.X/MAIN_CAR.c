/*
 * File:   MAIN_CAR.c
 * Author: ajay  reddy
 *
 * Created on May 29, 2024, 6:06 PM
 */

#include <xc.h>
#include"main.h"
#include "clcd.h"
#include"matrix_keypad.h"
#include "ds1307t.h"
extern unsigned char time[9]; //array to store time 
extern unsigned char ev[][3]; //array to display events
extern unsigned int ev_i = 0, status = 8; //status
extern unsigned int once;
extern unsigned short speed = 0;
unsigned short adc_reg_val;
extern unsigned char key,lap;
extern char menu_f;
extern int logcount=1;

static void init_config(void) {
    
    //init configuration
    init_clcd();
    init_adc();
    init_matrix_keypad();
    init_timer0();
    init_i2c();
    init_ds1307();
    init_uart();
    store_the_event(ev_i,speed);
    
    
    write_ext_eeprom(200,'1');
    write_ext_eeprom(201,'1');
    write_ext_eeprom(202,'1');
    write_ext_eeprom(203,'1');
   
}

void main(void) {
    init_config();
    

    while (1) {
        
        key = read_switches(STATE_CHANGE); //read switches
        if (status == DASHBOARD) 
        {
            
            adc_reg_val = read_adc(CHANNEL4); //reading potientiometer value adc
            speed = adc_reg_val / 10.23;
            dashboard(ev_i, speed); //calling display function
            if (key == MK_SW1) //collision
            {
                collision();
                logcount++; //increment log count
            }
            else if (key == MK_SW2) //increment event
            {
                store_the_event(ev_i, speed);
                if (ev_i == 6)
                {
                    ev_i = 2;
                } 
                else
                {
                    if (ev_i < 5) {
                        ev_i++;
                    }
                }
                logcount++;
            }
            else if (key == MK_SW3) //decrement event array
            {
                if (ev_i == 6)
                {
                    ev_i = 2;
                } 
                else 
                {
                    if (ev_i > 1)
                    {
                        ev_i--;

                    }
                }
                logcount++;
            }
        else if(key == MK_SW5)
        {
            status = PASSWORD; //update status to dashboard
            CLEAR_DISP_SCREEN;
        }
        }
        else if(status == PASSWORD) //password]
        {
            password();
            
        }
        else if(status == MENU)
        {
            disp_menu();
        }
        else if(status  == MENU_ENTER)
        {
            if(menu_f == VIEWLOG) //viewlog
            {
               view_log();
            }
            else if(menu_f == DOWNLOAD_LOG) //download log
            {
                download_log();
            }
            else if(menu_f == CLEAR_LOG) //clear log
            {
                clear_the_log();
            }
            else if(menu_f == SET_TIME) // set the time
            {
                set_the_time();
            }
            if(menu_f == CHANGE_PASS) //change  password
            {
             change_password();
            }
            
        }
        
    }
}
        


