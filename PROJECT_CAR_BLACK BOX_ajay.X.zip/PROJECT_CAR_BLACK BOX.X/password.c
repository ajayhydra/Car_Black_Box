/*
 * File:   password.c
 * Author: ajay  reddy
 *
 * Created on June 3, 2024, 6:25 PM
 */





#include <xc.h>
#include "clcd.h"
#include "main.h"
#include "matrix_keypad.h"
char pass[4];
int arr[4],res;
unsigned int status;
char key;
extern unsigned int sec;

int pass_cmp()
{
    for(int i=0;i<4;i++)
    {
        if(pass[i]!=arr[i])
        {
            return 0;
        }
    }
    return 1;
}
void password()
{
    static int p_count=0;
    static int flag=1,count=3,sflag=1,wdelay=0,delay=0;
    static int tdelay=0;
    if(p_count<4 && count>0)
    {
      clcd_print("ENTER PASSWORD",LINE1(0));
            //key=read_switches(STATE_CHANGE);
            if(key==ALL_RELEASED)
            {
                if(tdelay++==5000)
                {
                    tdelay=0;
                    status=DASHBOARD;
                    p_count=0;
                    count=3;
                    CLEAR_DISP_SCREEN;
                }
            }
            else
            {
                tdelay=0;
            }
            if(p_count<4)
            {
             if(delay++ <= 1000)
            {
                clcd_putch('_',LINE2(p_count));
            }
            else if(delay <=2000)
            {
                clcd_putch(' ',LINE2(p_count));
            }
            if(delay>2000)
            {
                delay=0;
            } 
            }
            if(key==MK_SW5 && p_count<4)
            {
                arr[p_count]='0';
                clcd_putch('*',LINE2(p_count));
                p_count++;
            }
            else if(key==MK_SW6 && p_count<4)
            {
                arr[p_count]='1';
                clcd_putch('*',LINE2(p_count));
                p_count++;
            }
    }
            if(p_count==4 && count>0)
            {
                res=pass_cmp();
                if(res==1)
                {
                    status=MENU;
                    p_count=0;
                    CLEAR_DISP_SCREEN;
                }
                else if(res==0)
                {
                    if(flag)
                    {
                    CLEAR_DISP_SCREEN;
                    flag=0;
                    }
                    clcd_print("TRY AGAIN",LINE1(0));
                    clcd_putch((count-1)+48,LINE2(0));
                    clcd_print(" attempt left",LINE2(1));
                    if(wdelay++==5000)
                    {
                        count--;
                        p_count=0;
                        wdelay=0;
                        flag=1;
                        CLEAR_DISP_SCREEN;
                    }
                }
            }
            else if(count==0)
            {
                flag=1;
                if(sflag)
                {
                    sec=180;
                    GIE=1;
                    TMR0=6;
                    PEIE=1;
                    sflag=0;
                }
                clcd_print("YOU ARE BLOCKED",LINE1(0));
                clcd_print("FOR ",LINE2(0));
                clcd_putch((sec/100)+48, LINE2(4));
                clcd_putch(((sec/10)%10)+48,LINE2(5));
                clcd_putch((sec%10)+48,LINE2(6));
                clcd_print(" SECONDS",LINE2(7));
                if(sec==0)
                {
                    count=3;
                    sflag=1;
                    GIE=0;
                    p_count=0;
                    CLEAR_DISP_SCREEN;
                }
                
            }
}    