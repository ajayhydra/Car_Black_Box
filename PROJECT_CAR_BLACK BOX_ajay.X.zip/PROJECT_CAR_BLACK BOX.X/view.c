/*
 * File:   view.c
 * Author: ajay  reddy
 *
 * Created on June 11, 2024, 5:51 PM
 */



#include <xc.h>
#include "main.h"
#include "clcd.h"
#include "matrix_keypad.h"

int logcount;
extern unsigned char key;
unsigned int once=1;
char ev[11][3];
unsigned int status;
static int count=0;


void view_log()
{
    
    static unsigned int pdelay=0;
    static unsigned char key1;
    char data,data1,data2;
    char arr[5];
    char view_key = read_switches(LEVEL_CHANGE); 
    clcd_print("LOG",LINE1(0));
    for(int i=0;i<5;i++)
    {
         data=read_ext_eeprom((count*5)+i); //reading data from eeprom
         arr[i]=data;
    }
    //printing on clccd
    clcd_putch(count+48,LINE2(0));
    clcd_putch((arr[0]/10)+48,LINE2(2));
    clcd_putch(arr[0]%10+48,LINE2(3));
    clcd_putch(':',LINE2(4));
    clcd_putch(arr[1]/10+48,LINE2(5));
    clcd_putch(arr[1]%10+48,LINE2(6));
    clcd_putch(':',LINE2(7));
    clcd_putch(arr[2]/10+48,LINE2(8));
    clcd_putch(arr[2]%10+48,LINE2(9));
    clcd_print(ev[arr[3]],LINE2(11));
    clcd_putch(arr[4]/10+48,LINE2(14));
    clcd_putch(arr[4]%10+48,LINE2(15));
    if(view_key == 0xFF)
    {
             once =1 ;
    }
     if(view_key!=ALL_RELEASED && once)
    {
        if(view_key==MK_SW5 && once)
        {
            key1 = view_key;
            once=0;
        }
        else if(view_key==MK_SW6 && once)
        {
            key1 = view_key;
            if(++pdelay==500)
            {
               once=0; 
            }
                
        }
        
    }
     else
     {
        
         if(key1==MK_SW5) //move logs downside
         {
             key1=0xFF;
             if(count>0)
             {
                 count--;
             }
         }
         else if(key1==MK_SW6 && pdelay!=500)
         {
             pdelay=0;
             key1=0xFF;
             if(count < logcount-1 )  // move  logs upside
             {
                 count++;
                 CLEAR_DISP_SCREEN;
             }
         }
         else if(key1==MK_SW6 && pdelay==500) // long press switch 6 go back
         {
             pdelay=0;
             key1 = 0xFF;
             CLEAR_DISP_SCREEN;
             count=0;
             status=MENU;
             
         }
     }
    
}

