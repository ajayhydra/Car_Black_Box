/*
 * File:   functions.c
 * Author: ajay  reddy
 *
 * Created on May 31, 2024, 4:46 PM
 */


#include <xc.h>
#include"clcd.h"
#include"main.h"
#include"matrix_keypad.h"
#include "ds1307t.h"

unsigned char time[9];
unsigned char ev[11][3]={"ON", "GR", "GN", "G1", "G2", "G3", "-C", "DL", "CL", "ST", "CP"};
unsigned int ev_i;
unsigned char lap=0;
unsigned short speed;
unsigned char clock_reg[3];


void dashboard(unsigned int ev_i,unsigned short speed)
{
        int i;
        get_time();
        clcd_print("TIME",LINE1(0));
        clcd_print("EV",LINE1(10));
        clcd_print("SP", LINE1(14));
        clcd_print(ev[ev_i],LINE2(10));
        for(i=0;i<8;i++)
        {
          clcd_putch(time[i],LINE2(i));
        }
        clcd_putch(speed/10+48,LINE2(14));
        clcd_putch(speed%10+48,LINE2(15));
        
}
 void collision(void)
 {    
     ev_i = 6;
     clcd_print(ev[ev_i],LINE2(10));
 }
 
 
void store_the_event(unsigned int ind,unsigned short speed)
{
    get_time();
    char arr[5];
    arr[0] = (time[0] - 48) * 10 + (time[1] - 48);
    arr[1] = (time[3] - 48) * 10 + (time[4] - 48);
    arr[2] = (time[4] - 48) * 10 + (time[7] - 48);
    arr[3] = ind;
    arr[4] = speed;
    for(unsigned char i=0;i<5;i++)
    {
        write_ext_eeprom((lap*5)+i,arr[i]);
    }
    if(lap!=9)
    {
        lap++;
    }
    else if(lap==9)
    {
        lap=0;
    }
    
}


void get_time(void)
{
	clock_reg[0] = read_ds1307(HOUR_ADDR);
	clock_reg[1] = read_ds1307(MIN_ADDR);
	clock_reg[2] = read_ds1307(SEC_ADDR);

	
		time[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
		time[1] = '0' + (clock_reg[0] & 0x0F);
	
	time[2] = ':';
	time[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
	time[4] = '0' + (clock_reg[1] & 0x0F);
	time[5] = ':';
	time[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
	time[7] = '0' + (clock_reg[2] & 0x0F);
	time[8] = '\0';
}

