/*
 * File:   isr.c
 * Author: ajay  reddy
 *
 * Created on June 4, 2024, 5:10 PM
 */


#include <xc.h>
#include "main.h"

unsigned int sec;
void __interrupt() isr(void)
{
    static int count=0;
	if (TMR0IF)
	{
		TMR0 = TMR0 + 8;

		if (count++ == 20000)
		{
			count = 0;
			sec--;
		}
        TMR0IF = 0;
	}
}
