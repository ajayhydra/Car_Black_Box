/*
 * File:   check_pass.c
 * Author: ajay  reddy
 *
 * Created on June 6, 2024, 11:03 AM
 */

#include <xc.h>
#include"clcd.h"
#include"main.h"
#include"matrix_keypad.h"

char pass[4];
unsigned char arr[4];
int res;
unsigned int status;
char key;
extern unsigned int sec;

int pass_cmp()
{
    int i;
    for(i=0;i<4;i++)
    {
        pass[i] = read_ext_eeprom(200+i);
        if(pass[i]!=arr[i])
        {
            return 0;
        }
    }
    return 1;
}
void password()
{
    static int p_count=0;
    static int flag=1,count=3,sflag=1,wdelay=0,delay=0;
    static int tdelay=0;
    if(p_count<4 && count>0)
    {
      clcd_print("ENTER PASSWORD",LINE1(0));
            //key=read_switches(STATE_CHANGE);
            if(key==ALL_RELEASED)
            {
                if(tdelay++==5000)
                {
                    tdelay=0;
                    status = DASHBOARD;
                    p_count=0;
                    count=3;
                    CLEAR_DISP_SCREEN;
                }
            }
            else
            {
                tdelay=0;
            }
      
            if(p_count<4)
            {
             if(delay++ <= 1000) //cursor blink
            {
                clcd_putch('_',LINE2(p_count));
            }
            else if(delay <=2000)
            {
                clcd_putch(' ',LINE2(p_count));
            }
            if(delay>2000)
            {
                delay=0;
            } 
            }
            if(key == MK_SW5 && p_count<4) //storing 1's and o's into array
            {
                arr[p_count]='0';
                clcd_putch('*',LINE2(p_count++));
            }
            else if(key == MK_SW6 && p_count<4)
            {
                arr[p_count]='1';
                clcd_putch('*',LINE2(p_count++));
                
            }
    }
            if(p_count==4 && count>0) //compare passwords
            {
                res=pass_cmp();
                if(res==1)
                {
                     int delay=0;
    if(++delay < 2000)
    {
        CLEAR_DISP_SCREEN;
        clcd_print("ENTERED IN TO",LINE1(0));
        clcd_print("MENU",LINE2(0));
    }
                    status = MENU;
                    p_count=0;
                    CLEAR_DISP_SCREEN;
                }
                else if(res==0) //wrong password 
                {
                    if(flag)
                    {
                    CLEAR_DISP_SCREEN;
                    flag=0;
                    }
                    clcd_print("TRY AGAIN",LINE1(0)); //displaying number of attempts left
                    clcd_putch((count-1)+48,LINE2(0));
                    clcd_print(" attempt left",LINE2(1));
                    if(wdelay++==5000)
                    {
                        count--;
                        p_count=0;
                        wdelay=0;
                        flag=1;
                        CLEAR_DISP_SCREEN;
                    }
                }
            }
            else if(count==0) //display delay for 3 minutes
            {
                flag=1;
                if(sflag)
                {
                    sec=180;
                    GIE=1;
                    PEIE=1;
                    sflag=0;
                }
                clcd_print("YOU ARE BLOCKED",LINE1(0));
                clcd_print("FOR ",LINE2(0));
                clcd_putch((sec/100)+48, LINE2(4));
                clcd_putch(((sec/10)%10)+48,LINE2(5));
                clcd_putch((sec%10)+48,LINE2(6));
                clcd_print(" SECONDS",LINE2(7));
                if(sec==0)
                {
                    count=3;
                    sflag=1;
                    GIE=0;
                    p_count=0;
                    CLEAR_DISP_SCREEN;
                   
                }
                
            }
}    